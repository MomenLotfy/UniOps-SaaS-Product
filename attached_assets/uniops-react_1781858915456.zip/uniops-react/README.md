# UniOps Landing — React + Vite

نسخة React (Vite) من صفحة UniOps الأصلية، بنفس الشكل والحركة والـ widgets تماماً.

## التشغيل

```bash
npm install
npm run dev
```

ثم افتح الرابط اللي يظهر في التيرمينال (افتراضياً `http://localhost:5173`).

## البناء للنشر

```bash
npm run build
```

الناتج هيكون في مجلد `dist/` — رفعه على Hostinger أو أي static host زي ما تعمل مع Lakatat.

## البنية

- `src/App.jsx` — تجميع كل السكاشن.
- `src/context/AppContext.jsx` — الـ theme (dark/light) والـ lang (en/ar)، بديل عن `setTheme`/`setLang` و الـ `localStorage` الأصليين.
- `src/components/FadeIn.jsx` — بديل الـ `IntersectionObserver` الأصلي لتأثير الظهور عند السكرول.
- `src/components/HeroWidgets.jsx` — كل الكاردز العائمة (Deploy sparkline, CI/CD, Cloud Cost, Active Tasks, Theme Mode, ML Serving, Clock, Live Alerts) — كل واحدة فيها الـ `setInterval` بتاعها بدل الـ intervals العامة في الكود الأصلي.
- `src/components/Navbar.jsx`, `Hero.jsx`, `Ticker.jsx`, `Metrics.jsx`, `Features.jsx`, `HowItWorks.jsx`, `CTA.jsx`, `Footer.jsx` — كل سكشن في كومبوننت لوحده.
- `src/i18n/translations.js` — قاموس الترجمة (en/ar) بنفس المفاتيح الأصلية.
- `src/index.css` — الـ CSS كامل منقول كما هو (متغيرات `:root`, الـ keyframes, RTL overrides, mobile breakpoints).

## ملاحظات

- الأيقونات بتيجي من نفس CDN اللي كان مستخدم في الملف الأصلي (`@tabler/icons-webfont` عبر jsdelivr) — لو حبيت تعزل المشروع عن أي CDN خارجي ينفع تستبدلها بـ `@tabler/icons-react` كـ npm package.
- مفيش أي تبعيات تانية غير React + Vite، فبتركب بسهولة جوه أي مشروع UniOps موجود بنفس الـ stack.
