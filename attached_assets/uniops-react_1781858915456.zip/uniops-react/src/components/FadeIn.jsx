import { useEffect, useRef, useState } from 'react';

export default function FadeIn({ as = 'div', className = '', style, children }) {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  const Tag = as;

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setVisible(true);
            obs.disconnect();
          }
        });
      },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  return (
    <Tag ref={ref} className={`fi-in${visible ? ' vis' : ''}${className ? ' ' + className : ''}`} style={style}>
      {children}
    </Tag>
  );
}
