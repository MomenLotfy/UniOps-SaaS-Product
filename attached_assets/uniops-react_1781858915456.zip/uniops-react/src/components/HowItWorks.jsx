import { useApp } from '../context/AppContext.jsx';
import FadeIn from './FadeIn.jsx';

export default function HowItWorks() {
  const { t } = useApp();

  const steps = [
    { n: '01', title: t('step1_t'), desc: t('step1_d') },
    { n: '02', title: t('step2_t'), desc: t('step2_d') },
    { n: '03', title: t('step3_t'), desc: t('step3_d') },
  ];

  return (
    <section id="how">
      <div className="sec-in">
        <FadeIn style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <span className="sec-tag">{t('how_tag')}</span>
          <h2 className="sec-h">{t('how_h')}</h2>
          <p className="sec-sub" style={{ textAlign: 'center' }}>{t('how_sub')}</p>
        </FadeIn>

        <FadeIn as="div" className="how-grid">
          <div className="how-line"></div>
          {steps.map((s) => (
            <div className="step" key={s.n}>
              <div className="step-n"><span>{s.n}</span></div>
              <div className="step-t">{s.title}</div>
              <div className="step-d">{s.desc}</div>
            </div>
          ))}
        </FadeIn>
      </div>
    </section>
  );
}
