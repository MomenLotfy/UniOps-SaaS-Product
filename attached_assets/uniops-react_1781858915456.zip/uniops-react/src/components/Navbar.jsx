import { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext.jsx';

export default function Navbar() {
  const { theme, toggleTheme, lang, setLang, t } = useApp();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <nav id="nav" className={scrolled ? 'sc' : ''}>
      <div className="nav-in">
        <a href="#" className="logo">
          <div className="logo-box">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <polygon points="12 2 22 8.5 22 15.5 12 22 2 15.5 2 8.5" />
              <line x1="12" y1="22" x2="12" y2="15.5" />
              <polyline points="22 8.5 12 15.5 2 8.5" />
            </svg>
          </div>
          <span className="logo-name">UniOps</span>
        </a>

        <div className="nav-links">
          <a href="#features" className="nl">{t('nav_features')}</a>
          <a href="#how" className="nl">{t('nav_how')}</a>
          <a href="#metrics" className="nl">{t('nav_metrics')}</a>
        </div>

        <div className="nav-right">
          <div className="pill-switch">
            <button className={`pill-btn${lang === 'en' ? ' active' : ''}`} onClick={() => setLang('en')}>EN</button>
            <button className={`pill-btn${lang === 'ar' ? ' active' : ''}`} onClick={() => setLang('ar')}>AR</button>
          </div>

          <button className="theme-btn" onClick={toggleTheme} title="Toggle theme">
            <i className={theme === 'dark' ? 'ti ti-moon' : 'ti ti-sun'}></i>
          </button>

          <a href="/login" className="btn-login">
            <i className="ti ti-login" style={{ fontSize: '.88rem' }}></i>
            Log In
          </a>

          <a href="#" className="btn-p">
            {t('nav_cta')}
            <i className="ti ti-arrow-right" style={{ fontSize: '.85rem' }}></i>
          </a>
        </div>
      </div>
    </nav>
  );
}
