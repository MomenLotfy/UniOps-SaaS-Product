import { useApp } from '../context/AppContext.jsx';
import FadeIn from './FadeIn.jsx';

export default function CTA() {
  const { t } = useApp();

  return (
    <section>
      <div className="sec-in">
        <FadeIn as="div" className="cta-box">
          <div className="cta-orb"></div>
          <span className="sec-tag">{t('cta_tag')}</span>
          <h2 className="cta-h">{t('cta_h')}</h2>
          <p className="cta-sub">{t('cta_sub')}</p>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '1rem', flexWrap: 'wrap', position: 'relative', zIndex: 1 }}>
            <a href="#" className="btn-hero">
              <span>{t('cta_btn1')}</span>
              <i className="ti ti-rocket" style={{ fontSize: '.95rem' }}></i>
            </a>
            <a href="#" className="btn-hero2">
              <i className="ti ti-calendar" style={{ fontSize: '.9rem' }}></i>
              <span>{t('cta_btn2')}</span>
            </a>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
