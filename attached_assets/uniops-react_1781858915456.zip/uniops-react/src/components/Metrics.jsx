import { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext.jsx';
import FadeIn from './FadeIn.jsx';

const BASE = [98.7, 247, 128, 23];
const NOISE = [0.8, 12, 15, 8];
const DEC = [1, 0, 0, 0];

export default function Metrics() {
  const { t } = useApp();
  const [vals, setVals] = useState(BASE);

  useEffect(() => {
    const id = setInterval(() => {
      setVals(BASE.map((b, i) => b + (Math.random() - 0.5) * NOISE[i]));
    }, 4000);
    return () => clearInterval(id);
  }, []);

  const fmt = (i) => (DEC[i] ? vals[i].toFixed(DEC[i]) : Math.round(vals[i]));

  return (
    <section id="metrics">
      <div className="sec-in">
        <FadeIn style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <span className="sec-tag">{t('metrics_tag')}</span>
          <h2 className="sec-h">{t('metrics_h')}</h2>
        </FadeIn>

        <FadeIn as="div" className="metric-grid">
          <div className="metric-card">
            <div className="m-val green">{fmt(0)}<span style={{ fontSize: '1rem' }}>%</span></div>
            <div className="m-lbl">{t('metric1')}</div>
            <div className="m-chg" style={{ color: '#4ade80' }}>↑ 2.3%</div>
          </div>
          <div className="metric-card">
            <div className="m-val blue">{fmt(1)}</div>
            <div className="m-lbl">{t('metric2')}</div>
            <div className="m-chg" style={{ color: '#60a5fa' }}>↑ 12 today</div>
          </div>
          <div className="metric-card">
            <div className="m-val amber">${fmt(2)}<span style={{ fontSize: '1rem' }}>K</span></div>
            <div className="m-lbl">{t('metric3')}</div>
            <div className="m-chg" style={{ color: '#f87171' }}>↑ 12.3% MTD</div>
          </div>
          <div className="metric-card">
            <div className="m-val purple">{fmt(3)}<span style={{ fontSize: '1rem' }}>ms</span></div>
            <div className="m-lbl">{t('metric4')}</div>
            <div className="m-chg" style={{ color: '#4ade80' }}>↓ 4ms</div>
          </div>
        </FadeIn>
      </div>
    </section>
  );
}
