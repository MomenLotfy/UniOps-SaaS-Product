import { useApp } from '../context/AppContext.jsx';
import HeroWidgets from './HeroWidgets.jsx';

export default function Hero() {
  const { t } = useApp();

  return (
    <section className="hero">
      <div className="hero-in">
        <div>
          <div className="hero-badge">
            <span className="badge-dot"></span>
            <span>{t('hero_badge')}</span>
          </div>

          <h1 className="hero-h1">
            <span>{t('hero_t1')}</span><br />
            <span className="gt">{t('hero_t2')}</span><br />
            <span>{t('hero_t3')}</span>
          </h1>

          <p className="hero-sub">{t('hero_sub')}</p>

          <div className="hero-btns">
            <a href="#" className="btn-hero">
              <span>{t('hero_btn1')}</span>
              <i className="ti ti-rocket" style={{ fontSize: '.95rem' }}></i>
            </a>
            <a href="#features" className="btn-hero2">
              <i className="ti ti-player-play" style={{ fontSize: '.9rem' }}></i>
              <span>{t('hero_btn2')}</span>
            </a>
          </div>

          <div className="hero-stats">
            <div>
              <div className="stat-num">500+</div>
              <div className="stat-lbl">{t('stat1')}</div>
            </div>
            <div>
              <div className="stat-num">99.9%</div>
              <div className="stat-lbl">{t('stat2')}</div>
            </div>
            <div>
              <div className="stat-num">40%</div>
              <div className="stat-lbl">{t('stat3')}</div>
            </div>
          </div>
        </div>

        <HeroWidgets />
      </div>
    </section>
  );
}
