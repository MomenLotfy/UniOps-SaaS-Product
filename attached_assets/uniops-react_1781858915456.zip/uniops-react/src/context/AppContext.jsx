import { createContext, useContext, useEffect, useState } from 'react';
import { I18N } from '../i18n/translations.js';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [theme, setThemeState] = useState(() => localStorage.getItem('uniops_theme') || 'dark');
  const [lang, setLangState] = useState(() => localStorage.getItem('uniops_lang') || 'en');

  // Keep <body data-theme> in sync (CSS variables are keyed off this attribute)
  useEffect(() => {
    document.body.setAttribute('data-theme', theme);
    localStorage.setItem('uniops_theme', theme);
  }, [theme]);

  // Keep <html lang/dir> in sync
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    localStorage.setItem('uniops_lang', lang);
  }, [lang]);

  const toggleTheme = () => setThemeState(t => (t === 'dark' ? 'light' : 'dark'));
  const setLang = (l) => setLangState(l);

  const t = (key) => I18N[lang]?.[key] ?? I18N.en[key] ?? key;

  const value = { theme, toggleTheme, lang, setLang, t };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
