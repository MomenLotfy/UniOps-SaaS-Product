import { AppProvider } from './context/AppContext.jsx';
import Navbar from './components/Navbar.jsx';
import Hero from './components/Hero.jsx';
import Ticker from './components/Ticker.jsx';
import Metrics from './components/Metrics.jsx';
import Features from './components/Features.jsx';
import HowItWorks from './components/HowItWorks.jsx';
import CTA from './components/CTA.jsx';
import Footer from './components/Footer.jsx';

function Page() {
  return (
    <>
      <div className="orb orb1"></div>
      <div className="orb orb2"></div>

      <Navbar />
      <Hero />
      <Ticker />
      <Metrics />

      <div className="div"></div>

      <Features />

      <div className="div"></div>

      <HowItWorks />

      <div className="div"></div>

      <CTA />
      <Footer />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <Page />
    </AppProvider>
  );
}
